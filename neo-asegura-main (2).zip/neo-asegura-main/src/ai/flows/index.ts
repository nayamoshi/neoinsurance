'use server';

import { aiRiskEstimator } from './ai-risk-estimator';
import { suggestCoverageName } from './ai-coverage-name-generator';

export { aiRiskEstimator, suggestCoverageName };
