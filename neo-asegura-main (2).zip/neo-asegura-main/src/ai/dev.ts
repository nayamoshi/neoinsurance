import { config } from 'dotenv';
config();

import '@/ai/flows/ai-risk-estimator.ts';
import '@/ai/flows/ai-coverage-name-generator.ts';
